﻿namespace OperatorLogAnalyzer
{
    partial class Form1
    {



    }
}

